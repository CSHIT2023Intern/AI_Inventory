from django.contrib import admin
from ._models import Img

admin.site.register(Img)