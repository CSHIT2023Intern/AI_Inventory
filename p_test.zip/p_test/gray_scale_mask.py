import os
from PIL import Image
import matplotlib
import numpy as np
import random
import cv2

COL = 2
ROW = 2
UNIT_HEIGHT_SIZE = 320  # 高
UNIT_WIDTH_SIZE = 320  # 寬
outPath = "./0816concat/"
PATH = "./0816_re/"
NAME = "0816_2concat"
RANDOM_SELECT = False
SAVE_QUALITY = 50


def gray(path, name, ImgN):
    img = cv2.imread(path+name)
    # img=Image.open(path+data)
    # img.show()
    rand = 0
    while rand < 3 and rand > -1.85:
        rand = random.uniform(-5.0, 5.0)
    a = 0
    if rand >= 0:
        a = 255

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    coImg = gray.astype(float)
    #zeros = np.zeros(np.array(img).shape, dtype=float)

    # coImg[np.where(coImg>=250)]=0
    """co2=coImg.copy()
    
    if a==255:
        coImg[np.where(coImg!=0)]-=a
        coImg[np.where(coImg!=0)]*=-1
        coImg[np.where(coImg!=0)]/=rand
        co2+=coImg
    else:
        rand*=-1
        coImg[np.where(coImg!=0)]/=rand
        co2-=coImg

"""
    rotateRand = random.randint(0, 360)
    coImg += 1
    b = np.array(Image.fromarray(coImg).rotate(rotateRand))
    b[np.where(b == 255)] = 200
    b[np.where(b == 0)] = 200
    b -= 1
    return Image.fromarray(b)


def concat_images(image_names, name, path, ImgN):
    image_files = []
    for index in range(COL*ROW):
        image_files.append(gray(path, image_names[index], ImgN))
    target = Image.new('RGB', (UNIT_WIDTH_SIZE * COL,
                       UNIT_HEIGHT_SIZE * ROW), "#FFFFFF")

    for row in range(ROW):
        for col in range(COL):

            target.paste(
                image_files[COL*row+col], (0 + UNIT_WIDTH_SIZE*col, 0 + UNIT_HEIGHT_SIZE*row))
    target.save(outPath + name + '.jpg', quality=SAVE_QUALITY)


def get_image_names(path):
    image_names = os.listdir(path)

    selected_images = random.choices(image_names, k=COL*ROW)
    return selected_images


if __name__ == '__main__':
    ImgN = 1
    for i in range(30):
        concat_images(get_image_names(PATH), str(i)+"_"+NAME, PATH, ImgN)
        ImgN += 1
