import os
import cv2
import numpy as np
import math
from PIL import Image
path = "0816"
height = 320


def add_white_edge(inImg, width, height):
    inImg = Image.fromarray(inImg)
    bgWidth = inImg.width
    bgHeight = inImg.height
    if bgWidth < bgHeight:
        bgWidth = math.ceil((bgHeight * width) / height)

    bgImg: Image.Image = Image.new("RGB", (bgWidth, bgHeight), (200, 200, 200))
    bgImg.paste(inImg, (round((bgWidth - inImg.width) / 2), 0))
    return np.array(bgImg)


if not os.path.isdir(path+"_re"):
    os.mkdir(path+"_re")
for imgName in os.listdir(path):
    img = cv2.imread("./"+path+"/"+imgName)
    imgh, imgw = img.shape[0], img.shape[1]
    width = int(imgw/imgh*height)
    newImg = cv2.resize(img, (width, height))
    newImg = add_white_edge(newImg, 320, 320)
    cv2.imwrite(path+"_re/"+imgName, newImg)
